package com.example.cs478project2;

import android.view.View;

public interface RVClick {
    public void onClick(View view, int position);

}
